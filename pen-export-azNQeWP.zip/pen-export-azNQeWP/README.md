# ประกาศผลมิชขั่นแรก

A Pen created on CodePen.

Original URL: [https://codepen.io/jetarisara-op/pen/azNQeWP](https://codepen.io/jetarisara-op/pen/azNQeWP).

