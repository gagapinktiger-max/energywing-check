const trainees = {
  "EW-T107": "Aujun",
  "EW-T242": "cheese”",
  "EW-T389": "creamcheese",
  "EW-T514": "Eugene.",
  "EW-T671": "Faris",
  "EW-T058": "jm",
  "EW-T903": "Neko",
  "EW-T426": "Rinari_n_aa",
  "EW-T775": "SEEN",
  "EW-T231": "TingLi",
  "EW-T690": "*Gin *o.®",
  "EW-T814": "ซิน",
  "EW-T159": "มิน (มุมิ) 201",
  "EW-T947": "& july",
  "EW-T364": "Joliee®®"
};

const passList = [
  "EW-T107","EW-T242","EW-T389","EW-T514","EW-T671",
  "EW-T058","EW-T903","EW-T426","EW-T775","EW-T231",
  "EW-T690","EW-T814","EW-T159","EW-T947","EW-T364"
];

function checkResult() {
  const code = document.getElementById("codeInput").value.trim().toUpperCase();
  const result = document.getElementById("result");
  const loading = document.getElementById("loading");
  const box = document.getElementById("resultBox");
  const nextBtn = document.getElementById("nextBtn");
  const infoCard = document.getElementById("infoCard");
  const infoText = document.getElementById("infoText");

  box.classList.remove("show");
  loading.style.display = "block";
  result.innerHTML = "";
  nextBtn.style.display = "none";
  infoCard.style.display = "none";

  if (!trainees[code]) {
    loading.style.display = "none";
    result.innerHTML = "<div class='fail'>ไม่พบโค้ดนี้ในระบบ</div>";
    box.classList.add("show");
    return;
  }

  setTimeout(() => {
    loading.style.display = "none";

    // ✅ แสดงการ์ดข้อมูลก่อน
    infoText.innerHTML = `
      <b>ชื่อผู้เข้าแข่งขัน:</b> ${trainees[code]}<br>
      <b>กลุ่ม:</b> ENERGYWING<br>
      <b>มิชชั่น:</b> รอบคัดเลือกครั้งที่ 1<br>
      <b>วันประกาศผล:</b> 9 พฤศจิกายน 2568
    `;
    infoCard.style.display = "block";

    setTimeout(() => {
      if (passList.includes(code)) {
        result.innerHTML = `<div class='pass'>${trainees[code]}<br>✅ ผ่านเข้ารอบ!</div>`;
        nextBtn.style.display = "block";
      } else {
        result.innerHTML = `<div class='fail'>${trainees[code]}<br>❌ ไม่ผ่าน</div>`;
      }

      box.classList.add("show");

      // ✅ เลื่อนลงอัตโนมัติ
      setTimeout(() => {
        box.scrollIntoView({ behavior: "smooth" });
      }, 300);

    }, 1500); // ✅ หน่วงหลังโชว์ข้อมูลก่อนลงผล

  }, 3000); // ✅ ลุ้นรอบแรก 3 วิ
}